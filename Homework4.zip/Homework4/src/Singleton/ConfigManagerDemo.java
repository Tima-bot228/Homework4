package Singleton;

public class ConfigManagerDemo {
    public static void main(String[] args) {
        ConfigurationManager config = ConfigurationManager.getInstance();

        System.out.println("Max Players: " + config.getConfig("maxPlayers"));
        System.out.println("Default Language: " + config.getConfig("defaultLanguage"));
        System.out.println("Game Difficulty: " + config.getConfig("gameDifficulty"));

        config.printAllConfigs();
    }
}
//Singleton (ConfigurationManager)
//
//Гарантирует, что создаётся только один экземпляр конфигурационного менеджера.
//Использует ленивую (lazy) и потокобезопасную инициализацию.
//Позволяет получить настройки и вывести их в консоль.