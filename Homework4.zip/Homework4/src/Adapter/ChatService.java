package Adapter;

public interface ChatService {
    void sendMessage(String message);
}
